#include "Cluster.h"

Cluster::Cluster(string s): fileName(s), numImages(0){
    build();
    read();
    hStart();
}

void Cluster::build(){
    //cout << fileName << endl;
    images.push_back(Image(fileName));
    numImages++;
}

void Cluster::hStart(){
    normHistoAverage.resize(64);
    //normHistoAverage = images[0] //DONT COPY, USE A REFERENCE
    normHistoAverage.assign(images[0].getNormRef().begin(),images[0].getNormRef().end());
    changed = true;
    deleted = false;
}


void Cluster::makeAverage(){
    //cout << "AVERAGE" << endl;
    double sum = 0.0f;
    int size = images.size();
    if (size > 1){
        for (int i = 0; i < 64; i++) {
            sum = 0.0f;
            for (vector<Image>::iterator iter = images.begin(); iter < images.end(); iter++) {
                sum += iter->normAt(i);
            }
            sum = sum/size;
            normHistoAverage[i] = sum;
        }
    }//else cout << "Size < 2, no recalc" << endl;
    
    
}


const Image& Cluster::imageRefAt(int i) const{
    return images[i];
}

Image Cluster::imageAt(int i) {
    return images[i];
}

int Cluster::getNumImages() const{
    return numImages;
}

int Cluster::read(){
    if (images[0].readNew() != 0){
        return -1;
    }
    return 0;
}

void Cluster::resetNumImages(){
    numImages = 0;
}

double Cluster::cNormAt(int i) const{
    return normHistoAverage[i];
}

const vector<double>& Cluster::getNormRef() const{
    return normHistoAverage;
}

void Cluster::addImage(Image im){
    images.push_back(im);
    numImages++;
}

int Cluster::getFlag(){
    return flag;
}

int Cluster::getClassNum() const{
    string temp;
    temp = fileName.substr(5,1);
    return (stoi(temp));
}

string Cluster::getClassName() const{
    return fileName;
}

bool Cluster::getChanged(){
    return changed;
}

void Cluster::setChanged(bool b){
    changed = b;
}

