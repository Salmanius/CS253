#include "Image.h"

Image::Image(string s): fileName(s), totalInts(0){};

int Image::readNew(){ //faster than old if atoi or naive is called
    ifstream is(fileName, ifstream::binary);
    istringstream targetBuffer;
    histogram.resize(64);  
    string rawInput;
    int rawI;
    int rangedVal;
    totalInts = 0;
    setClassName();
    if (is) {
        // get length of file:
        is.seekg (0, is.end);
        int length = is.tellg();
        is.seekg (0, is.beg);

        char * buffer = new char [length];
        // read data as a block:
        is.read (buffer,length);

        if (!is){
            cerr << "error: file could not be read";
        }
        is.close();
        targetBuffer.str(buffer);
        targetBuffer >> rawInput; //getting rid of P2
        targetBuffer >> rawInput; //getting rid of x
        targetBuffer >> rawInput; //getting rid of y
        targetBuffer >> rawInput; //getting rid of maxVal
        targetBuffer >> rawInput; //getting next for actual use
        //while (targetBuffer){
        for(int i = 0; i < 16348; i++){
            //cout << rawInput << endl;
            rawI = naive(rawInput.c_str());
            //rawI = atoi(rawInput.c_str());
            //rawI = stoi(rawInput);
            totalInts++;
            rangedVal = floor(rawI/4);
            histogram[rangedVal]++;
            targetBuffer >> rawInput;
        }
        
        
        /*
        while(targetBuffer){ //Slightly slower than above
            try{
                rawI = stoi(rawInput);
            }
            catch (std::exception const & e){
                break;
            }
            totalInts++;
            rangedVal = floor(rawI/4);
            histogram[rangedVal]++;
            targetBuffer >> rawInput;
        }
         * */
        singleNormalize();
        delete[] buffer;
        
    }
    else {//error file could not be openned
       cerr << "File could not be opened." << endl;
       return -1; 
    }
    
    return 0;
}



// // int Image::readOld(){ ///slightly slower than readNew when atoi or naive is called, otherwise slightly faster
// //     ifstream targetFile(fileName);
// //     histogram.resize(64);  
// //     int rawInput;
// //     int rangedVal;
// //     totalInts = 0;
// //     const int imageMaxValue = 255;
// //     setClassName();
// //     if (!targetFile.fail()){
// //         if (targetFile.fail()){
// //             cerr << "File is empty or incorrectly formatted." << endl;
// //             targetFile.close();
// //             return -4;
// //         }
// //         char c;
// //         targetFile.get(c);
// //         if (c != 'P') {
// //             cerr << "Header does not begin with P2." << endl;
// //             targetFile.close();
// //             return -5;
// //         } 
// //         targetFile.get(c);
// //         if (c != '2'){
// //             cerr << "Header does not begin with P2." << endl;
// //             targetFile.close();
// //             return -5;
// //         } 
// //         targetFile >> x;
// //         targetFile >> y;
// //         if (x != 128 || y != 128){
// //             cerr << "Incorrect dimensions" << endl;
// //             return -6;
// //         }
// //         targetFile >> rawInput ;
// //         if (targetFile.fail()){
// //             cerr << "File is incorrectly formatted with respect to dimensions" << endl;
// //             targetFile.close();
// //             return -6;
// //         }
// //         if (rawInput != imageMaxValue) {
// //             cerr << "Image max value is incorrect. Should be " << imageMaxValue << endl;
// //             targetFile.close();
// //             return -7;
// //         }
// //         targetFile >> rawInput;
// //         while (true){
// //             //cout << rawInput << endl;
// //             if (targetFile.eof()){
// //                 //cout << "EOF check HIT" << "rawinput=" << rawInput << " totalInts= " << totalInts << endl;		
// //                 if (x*y == 1 && (rawInput > 0 && rawInput < 256)){
// //                     totalInts++;
// //                 } 
// //                 if (totalInts != (x*y)){
// //                     cerr << "Pixel count does not equal x*y" << endl;
// //                     targetFile.close();
// //                     return -8;
// //                 }
// //                 singleNormalize();
// //                 targetFile.close();
// //                 return 0; 
// //             }
// //             if (targetFile.fail()){
// //                 cerr << "Bad input (not an integer)" << endl;
// //                 targetFile.close();
// //                 return -2;     
// //             }
// //                 
// //             if ((rawInput > 255) || (rawInput < 0)){
// //                 cerr << "Bad input (not in range): " << rawInput << endl;
// //                 targetFile.close();
// //                 return -3;
// //             }
// //             //calculations if it passes all the correct input tests
// //             totalInts++;
// //             rangedVal = floor(rawInput/4);
// //             histogram[rangedVal]++;
// //             targetFile >> rawInput;
// //         }
// //         //finished loading into the histogram. Normalizing to seperate vector
// //         targetFile.close();
// //         
// //     }
// //     else {//error file could not be openned
// //        cerr << "File could not be opened." << endl;
// //        return -1; 
// //     }
// //     
// //     return 0;
// // }

int Image::naive(const char *p) {
    int x = 0;
    while (*p >= '0' && *p <= '9') {
        x = (x*10) + (*p - '0');
        ++p;
    }
    return x;
}

void Image::singleNormalize(){
    //cout << "singleNormalize" << endl;
    normalized.resize(64);
    vector<float>::iterator norm = normalized.begin();
    vector<float>::iterator normEnd = normalized.end();
    vector<int>::iterator histo = histogram.begin();
    
    for (;norm < normEnd; norm++) {
        *norm = *histo/(float)totalInts;
        histo++;
    }    
}

string Image::getFileName() const {
    return fileName;
}

double Image::normAt(int i) const{
    return normalized[i];
}

const vector<float>& Image::getNormRef() const{
    return normalized;
}

void Image::setClassName() {
    string cN = fileName.substr(5,1);
    className = naive(cN.c_str());   
}

int Image::getClassName() const{
    return className;
}


